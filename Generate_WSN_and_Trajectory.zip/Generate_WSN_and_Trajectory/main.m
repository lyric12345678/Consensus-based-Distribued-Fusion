clear all
clc
warning off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Author: Ming Li
%Date:Feb. 10-2021
%Topic: Generate the wireless topology and the trajectory of a moving
%target
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Initial Parameters
[track_par]=Initial_par();
global  N sensor_num                                                       %Number of particles and sensors
N=5000;
sensor_num=25;

for i_mont=1:track_par.mont
    i_mont
    
    %% Generate Sensor Network
    [sensor_location] =Generate_Sensor_Network();
    
    %% Generate target state
    [target_state,Success_Gen] = Generate_Trajecity(track_par);
    load 'adjmtx'
    
    %% Plot out the wireless sensor network
    figure(1)
    for i=1:sensor_num
        for j=1:sensor_num
            if adjMtx(i,j)==1
                adjMtx(j,i)=0;
                h1=plot(sensor_location(i,1),sensor_location(i,2),'b.','MarkerSize',20);
                hold on
                plot(sensor_location(j,1),sensor_location(j,2),'b.','MarkerSize',20);
                a=[sensor_location(i,1),sensor_location(j,1)];
                b=[sensor_location(i,2),sensor_location(j,2)];
                h2=line(a,b,'linewidth',1,'LineStyle','--','color','b');
            end
        end
    end
    h3=plot(target_state(1,:),target_state(3,:),'r-','LineWidth',2);
    set(gca,'FontSize',22)
    set (gcf,'Position',[200,200,1000,800], 'color','w')
    xlabel('X','fontsize',22)
    ylabel('Y','fontsize',22)
    legend([h1,h2,h3],'Sensor Node','Sensor Link','Trajectory')
    grid on
end
