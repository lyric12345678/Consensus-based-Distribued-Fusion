% function [sensor_location] =Generate_Sensor_Network(track_par)
% %% ���ô�����λ��
% %�̶�������λ��
% % sensor_location=[0,0;0,0;0,0;0,0];    
% %�ڼ����������������Ĵ�����λ��
% global sensor_num
% sensor_x=randi([0,track_par.x_num]/10,sensor_num,1);
% sensor_y=randi([0,track_par.y_num]/10,sensor_num,1);
% sensor_location=[sensor_x,sensor_y];   
% end

%���߸����Ĵ���������ķ���
function [sensor_location] =Generate_Sensor_Network()
%This function allows the network topology to change dynamically from
%averaging cycle to averaging cycle. Since it uses global variables, it is
%called at the beginning of each averaging cycle with no arguments.
%
%This function generates the 2D physical topology of the sensor network. It
%changes two matrices in global parset. The first one being sensorsPos
%(numSensors x 2 matrix) containing XY coordinates of every sensor
%(in rows), and the second one being adjacencyMat (numSensors x numSensors
%matrix) defining neighborhood (adjacency matrix of the corresponding
%graph).
%Sensors are placed at "noisy rectangular grid" positions.


%Simulation parameters%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
numSensors_oneDir =5; % the number of sensors in one direction (mnumber of sensors in one direction of the noisy rectangular grid)
posDeviation =2; % controls the amount of "deviation" from the rectangular grid positions
neighborhoodRadius = 18; % the neighborhood of a given sensor is given by those sensors that are nearer than this value
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

simAreaSize = 40; % the simulation area is a square of simAreaSize x simAreaSize [m]
%NOTE: This value must be the same as the simAreaSize value found in main!

numSensors = numSensors_oneDir * numSensors_oneDir; % total number of sensors

gridStep = simAreaSize / (numSensors_oneDir - 1);

sensorsXY = zeros(numSensors,2);
sensorsXY(:,1) = repmat((0:(numSensors_oneDir-1))*gridStep,1,numSensors_oneDir);
sensorsXY(:,2) = reshape(repmat((0:(numSensors_oneDir-1))*gridStep,numSensors_oneDir,1),1,numSensors);
sensorsXY = sensorsXY + randn(numSensors,2)*posDeviation;

% make sure that sensor x and y coordinates are in the interval <0,simAreaSize>
sensorsXY(sensorsXY < 0) = 0;
sensorsXY(sensorsXY > simAreaSize) = simAreaSize;

% create adjacency matrix determined by the sensor positions and the neighborhood size:
adjMtx = zeros(numSensors);

for iter_sensor=1:numSensors
    
    for iter_sensor2=1:numSensors
        
        if (norm(sensorsXY(iter_sensor,:)-sensorsXY(iter_sensor2,:))<= neighborhoodRadius) && (iter_sensor ~= iter_sensor2)
            adjMtx (iter_sensor,iter_sensor2) = 1 ;
        end
    end
end

sensor_location= sensorsXY; %physical positions of the sensors
adjMtx = sparse(adjMtx);  %adjacency matrix of the graph representation of the sensor network (with communication links)

save adjMtx adjMtx
save sensor_XY sensor_location

% load 'adjmtx'
% sensor_num=length(adjMtx);
% % ������������
% % ������Ӧ����������ͼ
% figure(1)
% for i=1:sensor_num
%    for j=1:sensor_num
%       if adjMtx(i,j)==1
%          adjMtx(j,i)=0;
%        plot(sensor_location(i,1),sensor_location(i,2),'k.','MarkerSize',20);
%        hold on
%        plot(sensor_location(j,1),sensor_location(j,2),'k.','MarkerSize',20);
%        a=[sensor_location(i,1),sensor_location(j,1)];
%        b=[sensor_location(i,2),sensor_location(j,2)];
%        line(a,b,'linewidth',1,'LineStyle','--','color','k');
%       end
%    end
% end
% % axis([0,40,0,40]);
% legend('������·',2)

end
